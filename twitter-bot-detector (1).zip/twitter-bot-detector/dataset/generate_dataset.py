"""
Generates a SYNTHETIC Twitter/X account dataset for bot detection.

The data is statistically simulated (not scraped from real users) so the
project is self-contained and free of privacy/ToS issues. To use real data,
replace dataset/accounts.csv with your own file that has the same columns
(e.g. built from the Cresci-2017 / TwiBot-20 research datasets).
"""
import csv
import random
import math
import os

random.seed(42)
N = 4000
OUT = os.path.join(os.path.dirname(__file__), "accounts.csv")

COLUMNS = [
    "followers_count", "friends_count", "statuses_count", "account_age_days",
    "favourites_count", "listed_count", "has_profile_image", "has_description",
    "verified", "default_profile", "tweets_per_day", "retweet_ratio",
    "url_ratio", "hashtag_avg", "mention_avg", "duplicate_tweet_ratio",
    "username_digit_ratio", "label",
]


def clip(x, lo, hi):
    return max(lo, min(hi, x))


def human():
    age = int(random.uniform(120, 5000))
    followers = int(random.lognormvariate(5.5, 1.6))
    friends = int(random.lognormvariate(5.4, 1.2))
    tpd = clip(random.lognormvariate(0.8, 0.9), 0.05, 40)
    return {
        "followers_count": followers,
        "friends_count": friends,
        "statuses_count": int(tpd * age * random.uniform(0.4, 1.0)),
        "account_age_days": age,
        "favourites_count": int(random.lognormvariate(6.5, 1.8)),
        "listed_count": int(random.lognormvariate(0.8, 1.4)),
        "has_profile_image": int(random.random() < 0.97),
        "has_description": int(random.random() < 0.88),
        "verified": int(random.random() < 0.03),
        "default_profile": int(random.random() < 0.25),
        "tweets_per_day": round(tpd, 2),
        "retweet_ratio": round(clip(random.betavariate(2, 5), 0, 1), 3),
        "url_ratio": round(clip(random.betavariate(1.5, 8), 0, 1), 3),
        "hashtag_avg": round(clip(random.gauss(0.7, 0.5), 0, 5), 2),
        "mention_avg": round(clip(random.gauss(0.9, 0.6), 0, 5), 2),
        "duplicate_tweet_ratio": round(clip(random.betavariate(1, 30), 0, 1), 3),
        "username_digit_ratio": round(clip(random.betavariate(1.2, 12), 0, 1), 3),
        "label": 0,
    }


def bot():
    kind = random.choice(["spam", "amplifier", "fake_follower"])
    age = int(random.uniform(5, 900))
    if kind == "spam":
        tpd = clip(random.lognormvariate(3.2, 0.6), 10, 400)
        followers = int(random.lognormvariate(3.0, 1.2))
        friends = int(random.lognormvariate(7.0, 0.8))
        url, dup, rt = random.betavariate(6, 3), random.betavariate(5, 4), random.betavariate(2, 4)
    elif kind == "amplifier":
        tpd = clip(random.lognormvariate(2.6, 0.7), 5, 250)
        followers = int(random.lognormvariate(4.0, 1.3))
        friends = int(random.lognormvariate(6.5, 0.9))
        url, dup, rt = random.betavariate(2, 6), random.betavariate(3, 6), random.betavariate(8, 2)
    else:
        tpd = clip(random.lognormvariate(0.0, 1.0), 0.01, 8)
        followers = int(random.lognormvariate(2.5, 1.0))
        friends = int(random.lognormvariate(7.2, 0.6))
        url, dup, rt = random.betavariate(2, 8), random.betavariate(2, 10), random.betavariate(3, 4)
    return {
        "followers_count": followers,
        "friends_count": friends,
        "statuses_count": int(tpd * age * random.uniform(0.6, 1.0)),
        "account_age_days": age,
        "favourites_count": int(random.lognormvariate(3.0, 1.8)),
        "listed_count": int(random.lognormvariate(-0.5, 1.0)),
        "has_profile_image": int(random.random() < 0.65),
        "has_description": int(random.random() < 0.55),
        "verified": 0,
        "default_profile": int(random.random() < 0.65),
        "tweets_per_day": round(tpd, 2),
        "retweet_ratio": round(clip(rt, 0, 1), 3),
        "url_ratio": round(clip(url, 0, 1), 3),
        "hashtag_avg": round(clip(random.gauss(2.0, 1.2), 0, 8), 2),
        "mention_avg": round(clip(random.gauss(1.8, 1.4), 0, 8), 2),
        "duplicate_tweet_ratio": round(clip(dup, 0, 1), 3),
        "username_digit_ratio": round(clip(random.betavariate(4, 6), 0, 1), 3),
        "label": 1,
    }


def main():
    rows = []
    for _ in range(N):
        rows.append(bot() if random.random() < 0.4 else human())
    # label noise: ~3% of rows flipped so the task is not trivially separable
    for r in rows:
        if random.random() < 0.03:
            r["label"] = 1 - r["label"]
    with open(OUT, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=COLUMNS)
        w.writeheader()
        w.writerows(rows)
    print(f"Wrote {len(rows)} rows to {OUT}")


if __name__ == "__main__":
    main()

"""Train the bot-detection model and save it to model.joblib."""
import json
import os

import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, roc_auc_score
from sklearn.model_selection import train_test_split

from features import FEATURES, engineer

HERE = os.path.dirname(__file__)
DATA = os.path.join(HERE, "..", "dataset", "accounts.csv")


def main():
    df = pd.read_csv(DATA)
    X = engineer(df)[FEATURES]
    y = df["label"]
    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=7
    )
    model = RandomForestClassifier(
        n_estimators=300, max_depth=12, min_samples_leaf=3,
        class_weight="balanced", random_state=7, n_jobs=-1,
    )
    model.fit(X_tr, y_tr)
    proba = model.predict_proba(X_te)[:, 1]
    pred = (proba >= 0.5).astype(int)
    report = classification_report(y_te, pred, output_dict=True)
    auc = roc_auc_score(y_te, proba)
    print(classification_report(y_te, pred))
    print("ROC-AUC:", round(auc, 4))

    importances = sorted(
        zip(FEATURES, model.feature_importances_), key=lambda t: -t[1]
    )
    metrics = {
        "accuracy": round(report["accuracy"], 4),
        "precision_bot": round(report["1"]["precision"], 4),
        "recall_bot": round(report["1"]["recall"], 4),
        "f1_bot": round(report["1"]["f1-score"], 4),
        "roc_auc": round(auc, 4),
        "train_rows": int(len(X_tr)),
        "test_rows": int(len(X_te)),
        "importances": [{"feature": f, "weight": round(float(w), 4)} for f, w in importances],
    }
    joblib.dump(model, os.path.join(HERE, "model.joblib"))
    with open(os.path.join(HERE, "metrics.json"), "w") as f:
        json.dump(metrics, f, indent=2)
    print("Saved model.joblib and metrics.json")


if __name__ == "__main__":
    main()

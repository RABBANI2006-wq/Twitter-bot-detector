"""Shared feature engineering for training and inference."""
import numpy as np
import pandas as pd

RAW = [
    "followers_count", "friends_count", "statuses_count", "account_age_days",
    "favourites_count", "listed_count", "has_profile_image", "has_description",
    "verified", "default_profile", "tweets_per_day", "retweet_ratio",
    "url_ratio", "hashtag_avg", "mention_avg", "duplicate_tweet_ratio",
    "username_digit_ratio",
]

DERIVED = ["follower_friend_ratio", "log_followers", "log_friends", "tweets_per_follower"]
FEATURES = RAW + DERIVED


def engineer(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for c in RAW:
        if c not in out.columns:
            out[c] = 0
    out["follower_friend_ratio"] = out["followers_count"] / (out["friends_count"] + 1)
    out["log_followers"] = np.log1p(out["followers_count"])
    out["log_friends"] = np.log1p(out["friends_count"])
    out["tweets_per_follower"] = out["tweets_per_day"] / (out["followers_count"] + 1)
    return out

"""Flask prediction service. Run: python app.py  (port 8000)"""
import json
import os

import joblib
import pandas as pd
from flask import Flask, jsonify, request

from features import FEATURES, RAW, engineer

HERE = os.path.dirname(__file__)
MODEL_PATH = os.path.join(HERE, "model.joblib")
METRICS_PATH = os.path.join(HERE, "metrics.json")

app = Flask(__name__)
model = joblib.load(MODEL_PATH) if os.path.exists(MODEL_PATH) else None


def reasons(row, importances):
    """Plain-language signals that pushed the score toward 'bot'."""
    out = []
    if row["tweets_per_day"] > 50:
        out.append(f"Very high posting rate ({row['tweets_per_day']:.0f} tweets/day)")
    if row["duplicate_tweet_ratio"] > 0.3:
        out.append("Many duplicate or near-duplicate tweets")
    if row["follower_friend_ratio"] < 0.1 and row["friends_count"] > 500:
        out.append("Follows far more accounts than follow it back")
    if row["account_age_days"] < 60:
        out.append("Very new account")
    if row["url_ratio"] > 0.5:
        out.append("Most tweets contain links")
    if row["retweet_ratio"] > 0.7:
        out.append("Mostly retweets, little original content")
    if not row["has_profile_image"] or row["default_profile"]:
        out.append("Default or missing profile image/theme")
    if not row["has_description"]:
        out.append("Empty bio")
    if row["username_digit_ratio"] > 0.4:
        out.append("Username has many digits (auto-generated pattern)")
    if row["hashtag_avg"] > 3:
        out.append("Heavy hashtag stuffing")
    return out


@app.get("/health")
def health():
    return jsonify(status="ok", model_loaded=model is not None)


@app.get("/metrics")
def metrics():
    if not os.path.exists(METRICS_PATH):
        return jsonify(error="metrics not found, run train.py"), 404
    with open(METRICS_PATH) as f:
        return jsonify(json.load(f))


@app.post("/predict")
def predict():
    if model is None:
        return jsonify(error="model not trained, run train.py"), 503
    payload = request.get_json(force=True, silent=True) or {}
    row = {k: float(payload.get(k, 0) or 0) for k in RAW}
    df = engineer(pd.DataFrame([row]))
    proba = float(model.predict_proba(df[FEATURES])[0, 1])
    r = df.iloc[0].to_dict()
    return jsonify(
        bot_probability=round(proba, 4),
        label="bot" if proba >= 0.5 else "human",
        signals=reasons(r, None),
    )


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", 8000)))

import { Router } from "express";
import mongoose from "mongoose";
import Analysis from "../models/Analysis.js";
import { predict, sanitize, modelMetrics } from "../services/ml.js";
import { explainAnalysis, llmEnabled } from "../services/llm.js";

const router = Router();
const dbUp = () => mongoose.connection.readyState === 1;

router.post("/analyze", async (req, res, next) => {
  try {
    const handle = String(req.body.handle || "unknown").slice(0, 40).replace(/^@/, "");
    const features = sanitize(req.body.features);
    const result = await predict(features);
    const explanation = await explainAnalysis({
      handle: `@${handle}`,
      botProbability: result.bot_probability,
      label: result.label,
      signals: result.signals,
    });
    const payload = {
      handle,
      features,
      botProbability: result.bot_probability,
      label: result.label,
      signals: result.signals,
      explanation,
      source: result.source,
    };
    if (dbUp()) {
      const saved = await Analysis.create(payload);
      return res.json({ ...payload, _id: saved._id, createdAt: saved.createdAt });
    }
    res.json({ ...payload, createdAt: new Date().toISOString() });
  } catch (e) {
    next(e);
  }
});

router.get("/history", async (_req, res, next) => {
  try {
    if (!dbUp()) return res.json([]);
    res.json(await Analysis.find().sort({ createdAt: -1 }).limit(50).lean());
  } catch (e) {
    next(e);
  }
});

router.delete("/history/:id", async (req, res, next) => {
  try {
    if (dbUp() && mongoose.isValidObjectId(req.params.id))
      await Analysis.findByIdAndDelete(req.params.id);
    res.json({ ok: true });
  } catch (e) {
    next(e);
  }
});

router.get("/stats", async (_req, res, next) => {
  try {
    const metrics = await modelMetrics();
    let totals = { total: 0, bots: 0, humans: 0 };
    if (dbUp()) {
      const [bots, humans] = await Promise.all([
        Analysis.countDocuments({ label: "bot" }),
        Analysis.countDocuments({ label: "human" }),
      ]);
      totals = { total: bots + humans, bots, humans };
    }
    res.json({ ...totals, model: metrics, llm: llmEnabled() });
  } catch (e) {
    next(e);
  }
});

export default router;

import { Router } from "express";
import { chat } from "../services/llm.js";

const router = Router();

router.post("/", async (req, res, next) => {
  try {
    const raw = Array.isArray(req.body.messages) ? req.body.messages : [];
    const messages = raw
      .filter((m) => (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
      .map((m) => ({ role: m.role, content: m.content.slice(0, 2000) }));
    if (!messages.length || messages[messages.length - 1].role !== "user")
      return res.status(400).json({ error: "Last message must be from the user" });
    const reply = await chat(messages, req.body.lastAnalysis);
    res.json({ reply });
  } catch (e) {
    next(e);
  }
});

export default router;

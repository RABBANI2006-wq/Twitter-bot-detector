import mongoose from "mongoose";

const analysisSchema = new mongoose.Schema(
  {
    handle: { type: String, default: "unknown", trim: true },
    features: { type: Object, required: true },
    botProbability: { type: Number, required: true },
    label: { type: String, enum: ["bot", "human"], required: true },
    signals: [String],
    explanation: String,
    source: { type: String, enum: ["ml-model", "heuristic"], default: "ml-model" },
  },
  { timestamps: true }
);

export default mongoose.model("Analysis", analysisSchema);

const ML_URL = process.env.ML_URL || "http://127.0.0.1:8000";

export const FIELDS = [
  "followers_count", "friends_count", "statuses_count", "account_age_days",
  "favourites_count", "listed_count", "has_profile_image", "has_description",
  "verified", "default_profile", "tweets_per_day", "retweet_ratio",
  "url_ratio", "hashtag_avg", "mention_avg", "duplicate_tweet_ratio",
  "username_digit_ratio",
];

export function sanitize(input = {}) {
  const out = {};
  for (const k of FIELDS) {
    const n = Number(input[k]);
    out[k] = Number.isFinite(n) && n >= 0 ? n : 0;
  }
  return out;
}

// Rule-based fallback used when the Python ML service is unreachable.
function heuristic(f) {
  const signals = [];
  let s = 0;
  if (f.tweets_per_day > 50) { s += 0.25; signals.push(`Very high posting rate (${Math.round(f.tweets_per_day)} tweets/day)`); }
  if (f.duplicate_tweet_ratio > 0.3) { s += 0.2; signals.push("Many duplicate tweets"); }
  if (f.friends_count > 500 && f.followers_count / (f.friends_count + 1) < 0.1) { s += 0.15; signals.push("Follows far more accounts than follow it back"); }
  if (f.account_age_days < 60) { s += 0.1; signals.push("Very new account"); }
  if (f.url_ratio > 0.5) { s += 0.1; signals.push("Most tweets contain links"); }
  if (f.retweet_ratio > 0.7) { s += 0.1; signals.push("Mostly retweets"); }
  if (!f.has_profile_image || f.default_profile) { s += 0.1; signals.push("Default or missing profile image/theme"); }
  if (!f.has_description) { s += 0.05; signals.push("Empty bio"); }
  if (f.username_digit_ratio > 0.4) { s += 0.1; signals.push("Username has many digits"); }
  if (f.verified) s -= 0.3;
  const p = Math.min(0.99, Math.max(0.01, s));
  return { bot_probability: p, label: p >= 0.5 ? "bot" : "human", signals };
}

export async function predict(features) {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 5000);
    const r = await fetch(`${ML_URL}/predict`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(features),
      signal: ctrl.signal,
    });
    clearTimeout(t);
    if (!r.ok) throw new Error(`ML service ${r.status}`);
    return { ...(await r.json()), source: "ml-model" };
  } catch (e) {
    console.warn("ML service unavailable, using heuristic:", e.message);
    return { ...heuristic(features), source: "heuristic" };
  }
}

export async function modelMetrics() {
  try {
    const r = await fetch(`${ML_URL}/metrics`);
    return r.ok ? await r.json() : null;
  } catch {
    return null;
  }
}

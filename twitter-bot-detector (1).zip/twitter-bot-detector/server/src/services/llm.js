// Thin LLM client. Uses the Anthropic Messages API when ANTHROPIC_API_KEY is set,
// otherwise returns a deterministic template answer so the app works offline.
const API_KEY = process.env.ANTHROPIC_API_KEY;
const MODEL = process.env.LLM_MODEL || "claude-sonnet-5-5";

async function complete(system, messages, maxTokens = 500) {
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": API_KEY,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({ model: MODEL, max_tokens: maxTokens, system, messages }),
  });
  if (!r.ok) throw new Error(`LLM API ${r.status}`);
  const data = await r.json();
  return data.content?.map((b) => b.text || "").join("").trim();
}

export const llmEnabled = () => Boolean(API_KEY);

export async function explainAnalysis({ handle, botProbability, label, signals }) {
  const pct = Math.round(botProbability * 100);
  const fallback =
    `${handle || "This account"} scored ${pct}% bot likelihood and is classified as ${label}. ` +
    (signals.length
      ? `Main signals: ${signals.slice(0, 4).join("; ")}.`
      : "No strong bot-like signals were found.") +
    " This is a statistical estimate, not proof.";
  if (!API_KEY) return fallback;
  try {
    return await complete(
      "You explain Twitter/X bot-detection results to non-experts in 3-4 plain sentences. " +
        "Be calibrated: this is a probabilistic estimate, never accuse the account owner of wrongdoing, " +
        "and mention the strongest signals and one caveat.",
      [{ role: "user", content: JSON.stringify({ handle, botProbability, label, signals }) }],
      300
    );
  } catch (e) {
    console.warn("LLM explain failed:", e.message);
    return fallback;
  }
}

const CHAT_SYSTEM = `You are the assistant inside a Twitter/X bot-detection web app.
Help users understand bot detection: what features mean (follower/friend ratio, posting rate,
duplicate tweets, account age, profile completeness), how the Random Forest model works,
how to read a bot-probability score, and false positives. Be concise and honest about
uncertainty. You cannot look up live Twitter accounts; users enter account stats in the Analyzer.
If given the user's latest analysis result, use it to answer specific questions.`;

function offlineAnswer(question, last) {
  const q = question.toLowerCase();
  if (last && /(why|score|result|explain)/.test(q))
    return `The last analysis gave ${Math.round(last.botProbability * 100)}% (${last.label}). ` +
      (last.signals?.length ? `Signals: ${last.signals.join("; ")}.` : "No strong signals fired.");
  if (/ratio|follower/.test(q))
    return "A very low followers-to-following ratio with many followed accounts often indicates mass-following behaviour typical of bots, but celebrities and new users can look similar.";
  if (/model|random forest|algorithm/.test(q))
    return "The detector is a Random Forest trained on account metadata and behaviour features (posting rate, duplicates, link/retweet ratios, profile completeness, account age).";
  if (/false positive|wrong|accurate/.test(q))
    return "False positives happen: heavy-posting news accounts or brand-new users can resemble bots. Treat the score as a hint, not a verdict.";
  return "I can explain the features, the model, or your last result. Set ANTHROPIC_API_KEY on the server for full LLM answers.";
}

export async function chat(history, lastAnalysis) {
  const question = history[history.length - 1]?.content || "";
  if (!API_KEY) return offlineAnswer(question, lastAnalysis);
  const ctx = lastAnalysis
    ? `\n\nUser's latest analysis: ${JSON.stringify({
        handle: lastAnalysis.handle,
        botProbability: lastAnalysis.botProbability,
        label: lastAnalysis.label,
        signals: lastAnalysis.signals,
      })}`
    : "";
  try {
    return await complete(CHAT_SYSTEM + ctx, history.slice(-12), 500);
  } catch (e) {
    console.warn("LLM chat failed:", e.message);
    return offlineAnswer(question, lastAnalysis);
  }
}

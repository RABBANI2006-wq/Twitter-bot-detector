import { useEffect, useState, useCallback } from "react";
import Analyzer from "./components/Analyzer.jsx";
import Result from "./components/Result.jsx";
import History from "./components/History.jsx";
import Dashboard from "./components/Dashboard.jsx";
import ChatBot from "./components/ChatBot.jsx";
import { getHistory, getStats } from "./api.js";

const TABS = [
  { id: "analyze", label: "Analyze" },
  { id: "history", label: "History" },
  { id: "model", label: "Model" },
];

export default function App() {
  const [tab, setTab] = useState("analyze");
  const [result, setResult] = useState(null);
  const [history, setHistory] = useState([]);
  const [stats, setStats] = useState(null);

  const refresh = useCallback(async () => {
    try {
      const [h, s] = await Promise.all([getHistory(), getStats()]);
      setHistory(h);
      setStats(s);
    } catch {
      /* backend may be offline; UI still renders */
    }
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  const onResult = (r) => {
    setResult(r);
    refresh();
  };

  return (
    <div className="app">
      <header className="top">
        <div className="brand">
          <span className="logo" aria-hidden>◉</span>
          <div>
            <h1>BotScope</h1>
            <p>Twitter/X bot detection · ML + LLM</p>
          </div>
        </div>
        <nav role="tablist" aria-label="Sections">
          {TABS.map((t) => (
            <button
              key={t.id}
              role="tab"
              aria-selected={tab === t.id}
              className={tab === t.id ? "tab active" : "tab"}
              onClick={() => setTab(t.id)}
            >
              {t.label}
            </button>
          ))}
        </nav>
      </header>

      <main>
        {tab === "analyze" && (
          <div className="grid two">
            <Analyzer onResult={onResult} />
            <Result result={result} />
          </div>
        )}
        {tab === "history" && (
          <History items={history} onChange={refresh} onOpen={(r) => { setResult(r); setTab("analyze"); }} />
        )}
        {tab === "model" && <Dashboard stats={stats} />}
      </main>

      <ChatBot lastAnalysis={result} />
      <footer>
        Scores are statistical estimates trained on synthetic data. Don't use them as proof against any real person.
      </footer>
    </div>
  );
}

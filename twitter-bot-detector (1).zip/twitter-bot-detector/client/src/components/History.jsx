import { deleteHistory } from "../api.js";

export default function History({ items, onChange, onOpen }) {
  if (!items.length) {
    return (
      <section className="card empty">
        <h2>No history yet</h2>
        <p>Analyses are saved to MongoDB. Run one from the Analyze tab (and make sure MongoDB is running).</p>
      </section>
    );
  }
  return (
    <section className="card">
      <h2>Recent analyses</h2>
      <div className="table-wrap">
        <table>
          <thead>
            <tr><th>Account</th><th>Score</th><th>Verdict</th><th>When</th><th /></tr>
          </thead>
          <tbody>
            {items.map((r) => {
              const pct = Math.round(r.botProbability * 100);
              return (
                <tr key={r._id}>
                  <td><button className="link" onClick={() => onOpen(r)}>@{r.handle}</button></td>
                  <td>
                    <div className="mini"><span style={{ width: `${pct}%` }} className={pct >= 50 ? "bad" : "good"} /></div>
                    {pct}%
                  </td>
                  <td><span className={`pill ${r.label}`}>{r.label}</span></td>
                  <td className="muted">{new Date(r.createdAt).toLocaleString()}</td>
                  <td>
                    <button className="ghost" aria-label={`Delete ${r.handle}`}
                      onClick={async () => { await deleteHistory(r._id); onChange(); }}>✕</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </section>
  );
}

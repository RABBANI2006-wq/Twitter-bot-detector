import { useState } from "react";
import { analyze } from "../api.js";

const GROUPS = [
  {
    title: "Profile",
    fields: [
      ["followers_count", "Followers", "number"],
      ["friends_count", "Following", "number"],
      ["account_age_days", "Account age (days)", "number"],
      ["listed_count", "Listed count", "number"],
      ["favourites_count", "Likes given", "number"],
    ],
    toggles: [
      ["has_profile_image", "Custom profile image"],
      ["has_description", "Has bio"],
      ["verified", "Verified"],
      ["default_profile", "Default theme"],
    ],
  },
  {
    title: "Behaviour",
    fields: [
      ["statuses_count", "Total tweets", "number"],
      ["tweets_per_day", "Tweets / day", "number"],
      ["retweet_ratio", "Retweet ratio (0–1)", "ratio"],
      ["url_ratio", "Tweets with links (0–1)", "ratio"],
      ["duplicate_tweet_ratio", "Duplicate tweets (0–1)", "ratio"],
      ["hashtag_avg", "Avg hashtags / tweet", "number"],
      ["mention_avg", "Avg mentions / tweet", "number"],
      ["username_digit_ratio", "Digits in username (0–1)", "ratio"],
    ],
    toggles: [],
  },
];

const BLANK = {
  followers_count: 300, friends_count: 300, account_age_days: 1000, listed_count: 2,
  favourites_count: 1000, statuses_count: 3000, tweets_per_day: 3, retweet_ratio: 0.2,
  url_ratio: 0.1, duplicate_tweet_ratio: 0, hashtag_avg: 0.6, mention_avg: 1,
  username_digit_ratio: 0.05, has_profile_image: 1, has_description: 1, verified: 0, default_profile: 0,
};

const SAMPLES = {
  "Sample human": { handle: "maya_writes", f: BLANK },
  "Sample bot": {
    handle: "deals4u_88217",
    f: {
      followers_count: 12, friends_count: 1800, account_age_days: 25, listed_count: 0,
      favourites_count: 3, statuses_count: 9000, tweets_per_day: 120, retweet_ratio: 0.6,
      url_ratio: 0.7, duplicate_tweet_ratio: 0.5, hashtag_avg: 4, mention_avg: 2,
      username_digit_ratio: 0.5, has_profile_image: 0, has_description: 0, verified: 0, default_profile: 1,
    },
  },
};

export default function Analyzer({ onResult }) {
  const [handle, setHandle] = useState("maya_writes");
  const [f, setF] = useState(BLANK);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const set = (k, v) => setF((p) => ({ ...p, [k]: v }));

  async function submit(e) {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      onResult(await analyze(handle, f));
    } catch {
      setError("Could not reach the server. Is the backend running on port 5000?");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form className="card" onSubmit={submit}>
      <div className="card-head">
        <h2>Account details</h2>
        <div className="chips">
          {Object.entries(SAMPLES).map(([name, s]) => (
            <button type="button" key={name} className="chip" onClick={() => { setHandle(s.handle); setF(s.f); }}>
              {name}
            </button>
          ))}
        </div>
      </div>

      <label className="field">
        <span>Handle</span>
        <div className="at"><i>@</i><input value={handle} maxLength={40} onChange={(e) => setHandle(e.target.value)} /></div>
      </label>

      {GROUPS.map((g) => (
        <fieldset key={g.title}>
          <legend>{g.title}</legend>
          <div className="fields">
            {g.fields.map(([k, label, kind]) => (
              <label className="field" key={k}>
                <span>{label}</span>
                <input
                  type="number" min="0" step={kind === "ratio" ? "0.01" : "any"}
                  max={kind === "ratio" ? 1 : undefined}
                  value={f[k]} onChange={(e) => set(k, e.target.value === "" ? "" : Number(e.target.value))}
                />
              </label>
            ))}
          </div>
          {g.toggles.length > 0 && (
            <div className="toggles">
              {g.toggles.map(([k, label]) => (
                <label key={k} className="toggle">
                  <input type="checkbox" checked={!!f[k]} onChange={(e) => set(k, e.target.checked ? 1 : 0)} />
                  <span>{label}</span>
                </label>
              ))}
            </div>
          )}
        </fieldset>
      ))}

      {error && <p className="error" role="alert">{error}</p>}
      <button className="primary" disabled={loading}>{loading ? "Analyzing…" : "Detect bot"}</button>
    </form>
  );
}

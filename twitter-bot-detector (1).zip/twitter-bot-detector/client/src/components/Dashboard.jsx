export default function Dashboard({ stats }) {
  const m = stats?.model;
  if (!stats) {
    return <section className="card empty"><h2>Backend offline</h2><p>Start the server to see model stats.</p></section>;
  }
  const max = m ? Math.max(...m.importances.map((i) => i.weight)) : 1;
  return (
    <div className="grid two">
      <section className="card">
        <h2>Usage</h2>
        <div className="stats">
          <div><b>{stats.total}</b><span>analyses</span></div>
          <div><b className="bad-t">{stats.bots}</b><span>bots</span></div>
          <div><b className="good-t">{stats.humans}</b><span>humans</span></div>
        </div>
        <p className="muted">LLM explanations: {stats.llm ? "enabled (Anthropic API)" : "offline template mode (set ANTHROPIC_API_KEY)"}</p>
        {m && (
          <>
            <h3>Test-set performance</h3>
            <div className="stats">
              <div><b>{(m.accuracy * 100).toFixed(1)}%</b><span>accuracy</span></div>
              <div><b>{(m.f1_bot * 100).toFixed(1)}%</b><span>bot F1</span></div>
              <div><b>{m.roc_auc.toFixed(3)}</b><span>ROC-AUC</span></div>
            </div>
            <p className="muted">{m.train_rows} train / {m.test_rows} test rows (synthetic dataset).</p>
          </>
        )}
      </section>
      <section className="card">
        <h2>What the model looks at</h2>
        {m ? (
          <ul className="bars">
            {m.importances.slice(0, 10).map((i) => (
              <li key={i.feature}>
                <span>{i.feature.replaceAll("_", " ")}</span>
                <div><i style={{ width: `${(i.weight / max) * 100}%` }} /></div>
                <small>{(i.weight * 100).toFixed(1)}%</small>
              </li>
            ))}
          </ul>
        ) : (
          <p className="muted">ML service offline. Run <code>python app.py</code> in ml-service/.</p>
        )}
      </section>
    </div>
  );
}

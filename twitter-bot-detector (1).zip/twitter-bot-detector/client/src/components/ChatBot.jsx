import { useEffect, useRef, useState } from "react";
import { sendChat } from "../api.js";

const SUGGESTIONS = ["Why did I get this score?", "What is the follower/following ratio?", "How does the model work?", "Can it be wrong?"];

export default function ChatBot({ lastAnalysis }) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [input, setInput] = useState("");
  const [msgs, setMsgs] = useState([
    { role: "assistant", content: "Hi! I can explain bot-detection signals, the model, or your latest result." },
  ]);
  const end = useRef(null);
  useEffect(() => { end.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs, open]);

  async function send(text) {
    const q = text.trim();
    if (!q || busy) return;
    const next = [...msgs, { role: "user", content: q }];
    setMsgs(next);
    setInput("");
    setBusy(true);
    try {
      // the API expects the conversation to start with a user turn
      const convo = next.filter((_, i) => i > 0);
      const { reply } = await sendChat(convo, lastAnalysis);
      setMsgs([...next, { role: "assistant", content: reply }]);
    } catch {
      setMsgs([...next, { role: "assistant", content: "Sorry, I can't reach the server right now." }]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <button className="fab" onClick={() => setOpen((o) => !o)} aria-expanded={open} aria-label="Toggle assistant">
        {open ? "✕" : "💬"}
      </button>
      {open && (
        <aside className="chat" aria-label="Assistant">
          <div className="chat-head">Assistant</div>
          <div className="chat-body">
            {msgs.map((m, i) => <div key={i} className={`bubble ${m.role}`}>{m.content}</div>)}
            {busy && <div className="bubble assistant typing">…</div>}
            <div ref={end} />
          </div>
          {msgs.length < 3 && (
            <div className="chips pad">
              {SUGGESTIONS.map((s) => <button key={s} className="chip" onClick={() => send(s)}>{s}</button>)}
            </div>
          )}
          <form className="chat-input" onSubmit={(e) => { e.preventDefault(); send(input); }}>
            <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask anything…" maxLength={500} />
            <button disabled={busy || !input.trim()}>Send</button>
          </form>
        </aside>
      )}
    </>
  );
}

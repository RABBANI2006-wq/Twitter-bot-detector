export default function Result({ result }) {
  if (!result) {
    return (
      <section className="card empty">
        <div className="ring ghost" />
        <h2>No analysis yet</h2>
        <p>Fill in an account's stats, or load a sample, then press <b>Detect bot</b>.</p>
      </section>
    );
  }
  const pct = Math.round(result.botProbability * 100);
  const tone = pct >= 70 ? "bad" : pct >= 40 ? "warn" : "good";
  const verdict = pct >= 70 ? "Likely a bot" : pct >= 40 ? "Uncertain" : "Likely human";
  const C = 2 * Math.PI * 54;

  return (
    <section className="card result" aria-live="polite">
      <div className="gauge-row">
        <div className={`gauge ${tone}`}>
          <svg viewBox="0 0 120 120" role="img" aria-label={`Bot probability ${pct} percent`}>
            <circle cx="60" cy="60" r="54" className="track" />
            <circle
              cx="60" cy="60" r="54" className="bar"
              strokeDasharray={C} strokeDashoffset={C * (1 - result.botProbability)}
              transform="rotate(-90 60 60)"
            />
          </svg>
          <div className="gauge-text"><b>{pct}%</b><small>bot score</small></div>
        </div>
        <div>
          <p className={`verdict ${tone}`}>{verdict}</p>
          <h2>@{result.handle}</h2>
          <p className="muted">Engine: {result.source === "ml-model" ? "Random Forest" : "Rule-based fallback"}</p>
        </div>
      </div>

      <h3>Why</h3>
      <p className="explain">{result.explanation}</p>

      <h3>Signals</h3>
      {result.signals?.length ? (
        <ul className="signals">{result.signals.map((s) => <li key={s}>{s}</li>)}</ul>
      ) : (
        <p className="muted">No bot-like red flags detected.</p>
      )}
    </section>
  );
}

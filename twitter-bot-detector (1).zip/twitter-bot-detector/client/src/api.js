async function request(path, options) {
  const res = await fetch(`/api${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) throw new Error(`Request failed (${res.status})`);
  return res.json();
}

export const analyze = (handle, features) =>
  request("/analyze", { method: "POST", body: JSON.stringify({ handle, features }) });
export const getHistory = () => request("/history");
export const deleteHistory = (id) => request(`/history/${id}`, { method: "DELETE" });
export const getStats = () => request("/stats");
export const sendChat = (messages, lastAnalysis) =>
  request("/chat", { method: "POST", body: JSON.stringify({ messages, lastAnalysis }) });
